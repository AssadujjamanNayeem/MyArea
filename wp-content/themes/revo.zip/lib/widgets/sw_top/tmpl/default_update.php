<?php
$instance = array();

// strip tag on text field
$instance['title'] = strip_tags( $new_instance['title'] );

// int or array

$instance['widget_template'] = strip_tags( $new_instance['widget_template'] );