<?php get_header(); ?>
<div class="container">
	<div class="single main" >
		<?php get_template_part('mlayouts/content', 'single');	?>
	</div>
</div>
<?php get_footer(); ?>
