<?php get_template_part( 'templates/content' );	?>
	