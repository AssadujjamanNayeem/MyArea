<?php
$less_variables = array(
	'color'        => '#ff5c00',
	'a-color'      => '#ff5c00',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/default'",
);

