<?php
$less_variables = array(
	'color'        => '#0f8db3',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/blue'",
);


