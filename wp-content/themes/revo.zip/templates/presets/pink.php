<?php
$less_variables = array(
	'color'        => '#f5487d',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/pink'",
);


