<?php
$less_variables = array(
	'color'        => '#b0d235',
	'a-color'      => 'desaturate(darken(@color, 20%),4%)',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/green'",
);


