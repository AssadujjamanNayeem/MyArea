<?php
$less_variables = array(
	'color'        => '#faa600',
	'a-color'      => '#faa600',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/orange'",
);

