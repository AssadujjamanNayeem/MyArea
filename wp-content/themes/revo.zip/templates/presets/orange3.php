<?php
$less_variables = array(
	'color'        => '#ee8e12',
	'a-color'      => '#ee8e12',
	'body-color'   => '#222',
	'border-color' => '#ccc',
	'url'     => "'../assets/img/orange2'",
);

