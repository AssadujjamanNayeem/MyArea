<?php
/**
 * Plugin Name: SW Popup
 * Plugin URI: http://www.smartaddons.com
 * Description: This plugin allow customer can configure popup
 * Version: 1.0.0
 * Author: Smartaddons
 * Author URI: http://www.smartaddons.com
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit; 
}
/* define plugin URL */
if ( ! defined( 'BNURL' ) ) {
	define( 'BNURL', plugins_url(). '/sw_popup' );
}

function swbn_placeholder_img_src(){
	return BNURL . '/images/placeholder.png' ;
}

class Sw_PopUp{
	function __construct(){
		add_action( "admin_menu", array( $this, "sw_add_theme_menu_item" ) );
		add_action( "admin_init", array( $this, "sw_display_theme_panel_fields" ) );
		add_action( "admin_enqueue_scripts", array( $this, "sw_popup_script" ) );
		add_action('wp_enqueue_scripts', array( $this, 'sw_scripts_popup' ), 1100);
		add_action( 'wp_footer', array( $this  , 'sw_widget_footer' ), 110 );	
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array( $this, 'sw_popup_plugin_action_links' ) );
	}
	
	function sw_popup_script(){
		wp_enqueue_style( 'popup_option', BNURL .'/css/admin/style.css',array(), null );
	}
	
	function sw_scripts_popup(){
		wp_enqueue_style('popup_style', BNURL . '/css/style.css', array(), null);
	}
	
	function sw_add_theme_menu_item() {
		add_menu_page(
			esc_html__( "SW PopUp", 'sw_popup' ),
					esc_html__( "SW PopUp", 'sw_popup' ),
			'manage_options',
			'sw-popup',
					array( $this, "sw_theme_settings_page" ),
			'dashicons-admin-generic',
			1000
		);
	}
	
	function sw_popup_plugin_action_links( $links ){
		$action_links = array(
			'settings' => '<a href="' . admin_url( 'admin.php?page=sw-popup' ) . '" aria-label="' . esc_attr__( 'View popup settings', 'sw_popup' ) . '">' . esc_html__( 'Settings', 'sw_popup' ) . '</a>',
		);

		return array_merge( $action_links, $links );
	}
	
	function get_value( $option_id ){
		$options = get_option( 'sw_popup' );		
		if( in_array( $option_id, array( 'pu_url', 'raw_html', 'banner_img', 'bg_img' ) ) ){
			return isset( $options[$option_id] ) ? $options[$option_id] : '';
		}elseif( in_array( $option_id, array( 'enable', 'pu_height', 'pu_width', 'pu_expire' ) ) ){
			return isset( $options[$option_id] ) ? $options[$option_id] : 0;
		}
	}
	
	function sw_theme_settings_page() {
?>
				<div class="setting-popup-panel">
				<h1><?php esc_html_e( 'Theme Panel', 'sw_popup' ) ?></h1>
				<form method="post" action="options.php">			
					<?php settings_fields("section_poup"); ?>
					<div id="setting_popup">
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Enable popup', 'sw_popup' ) ?></li>
							<li class="setting-content"><input type="checkbox" name="sw_popup[enable]" value="1" <?php checked(1, $this->get_value( 'enable' ), true); ?> /> </li>
						</ul>						
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Background Image', 'sw_popup' ) ?></li>
							<li class="setting-content">
								<?php
									if ( $this->get_value( 'bg_img' ) ) {
										$image2 = wp_get_attachment_thumb_url( $this->get_value( 'bg_img' ) );
									} else {
										$image2 = swbn_placeholder_img_src();
									}
								?>
								<div class="form-upload">
									<div class="product-thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( $image2 ); ?>" width="30px" height="30px" /></div>
									<div style="line-height: 30px;">
										<input type="hidden" class="thumbnail" name="sw_popup[bg_img]" value="<?php echo esc_attr( $this->get_value( 'bg_img' ) ) ?>"/>
										<button type="button" class="upload_image_button button"><?php _e( 'Upload/Add image', 'sw_popup' ); ?></button>
										<button type="button" class="remove_image_button button"><?php _e( 'Remove image', 'sw_popup' ); ?></button>
									</div>									
								</div>
							</li>
						</ul>
					</div>				
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Popup URL', 'sw_popup' ) ?></li>
							<li class="setting-content"><input type="text" name="sw_popup[pu_url]" value="<?php echo esc_url( $this->get_value( 'pu_url' ) ); ?>" size="60"/> </li>
						</ul>
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Popup Width', 'sw_popup' ) ?></li>
							<li class="setting-content"><input type="number" name="sw_popup[pu_width]" value="<?php echo esc_attr( $this->get_value( 'pu_width' ) ); ?>" size="60"/> </li>
						</ul>
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Popup Height', 'sw_popup' ) ?></li>
							<li class="setting-content"><input type="number" name="sw_popup[pu_height]" value="<?php echo esc_attr( $this->get_value( 'pu_height' ) ); ?>" size="60"/> </li>
						</ul>
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Time Expire', 'sw_popup' ) ?></li>
							<li class="setting-content"><input type="number" name="sw_popup[pu_expire]" value="<?php echo esc_attr( $this->get_value( 'pu_expire' ) ); ?>" size="60"/> </li>
						</ul>
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Banner Image', 'sw_popup' ) ?></li>
							<li class="setting-content">
								<?php
									if ( $this->get_value( 'banner_img' ) ) {
										$image = wp_get_attachment_thumb_url( $this->get_value( 'banner_img' ) );
									} else {
										$image = swbn_placeholder_img_src();
									}
								?>
								<div class="form-upload">
									<div class="product-thumbnail" style="float: left; margin-right: 10px;"><img src="<?php echo esc_url( $image ); ?>" width="30px" height="30px" /></div>
									<div style="line-height: 30px;">
										<input type="hidden" class="thumbnail" name="sw_popup[banner_img]" value="<?php echo esc_attr( $this->get_value( 'banner_img' ) ) ?>"/>
										<button type="button" class="upload_image_button button"><?php _e( 'Upload/Add image', 'sw_popup' ); ?></button>
										<button type="button" class="remove_image_button button"><?php _e( 'Remove image', 'sw_popup' ); ?></button>
									</div>									
								</div>
							</li>
						</ul>
					</div>
					
					<div class="setting-wrapper">
						<ul class="clearfix">
							<li class="label"><?php esc_html_e( 'Raw HTML', 'sw_popup' ) ?></li>
							<li class="setting-content"><?php wp_editor( get_option( 'popup_raw_html' ), 'popup_raw_html', array() ); ?></li>
						</ul>
					</div>					
					<div class="setting-popup-bottom">
						<?php submit_button(); ?>          
					</div>
				</form>
			</div>
			<script type="text/javascript"> 
				(function($) {
					"use strict";									
					function sw_upload_image( tar_parent ){
						// Only show the "remove image" button when needed
						if ( ! tar_parent.find( '.thumbnail' ).val() ) {
							tar_parent.find( '.remove_image_button' ).hide();
						}

						// Uploading files
						var file_frame;

						tar_parent.find( '.upload_image_button' ).on( 'click', function( event ) {

							event.preventDefault();

							// If the media frame already exists, reopen it.
							if ( file_frame ) {
								file_frame.open();
								return;
							}

							// Create the media frame.
							file_frame = wp.media.frames.downloadable_file = wp.media({
								title: '<?php _e( "Choose an image", 'sw_woocommerce' ); ?>',
								button: {
									text: '<?php _e( "Use image", 'sw_woocommerce' ); ?>'
								},
								multiple: false
							});

							// When an image is selected, run a callback.
							file_frame.on( 'select', function() {
								var attachment = file_frame.state().get( 'selection' ).first().toJSON();
								console.log( attachment );
								tar_parent.find( '.thumbnail' ).val( attachment.id );
								tar_parent.find( '.product-thumbnail > img' ).attr( 'src', attachment.sizes.thumbnail.url );
								tar_parent.find( '.remove_image_button' ).show();
							});

							// Finally, open the modal.
							file_frame.open();
						});

						tar_parent.find( '.remove_image_button' ).on( 'click', function() {
							tar_parent.find( '.product-thumbnail > img' ).attr( 'src', '<?php echo esc_js( swbn_placeholder_img_src() ); ?>' );
							tar_parent.find( '.thumbnail' ).val( '' );
							tar_parent.find( '.remove_image_button' ).hide();
							return false;
						});
					}
		
					$( '.form-upload' ).each( function(){
						sw_upload_image( $(this) );
					});					
				})(jQuery);
			</script>
		<?php
	}

	function sw_display_theme_panel_fields() {
		add_settings_section("section_poup", "SW PopUp", null, "theme-options");	
		global $sw_options;
		register_setting( "section_poup", "sw_popup", array() );
		register_setting( "section_poup", "popup_raw_html" );
	}	
	
	function sw_sanitize(){
		
	}	
	
	function sw_widget_footer(){
		$sw_theme = strtolower( str_replace( ' ', '-', wp_get_theme()->get( 'Name' ) ) ); 
		var_dump(  );
		if( !$this->get_value( 'enable' ) || ( isset( $_COOKIE['sw_popup'] ) && $_COOKIE['sw_popup'] == 1 ) ){
			return;
		}
		$attributes = ( $this->get_value( 'pu_height' ) ) ? 'height:' . $this->get_value( 'pu_height' ) . 'px;' : '';
		$attributes .= ( $this->get_value( 'pu_width' ) ) ? 'width:' . $this->get_value( 'pu_width' ) . 'px;' : '';
		$bg_attribute = ( $this->get_value( 'bg_img' ) ) ? 'background-image: url( '. wp_get_attachment_image_url( $this->get_value( 'bg_img' ), 'full' ) .');' : '';
?>
		<div class="sw-popup-wrapper" style="<?php echo esc_attr( $bg_attribute ); ?>">
			<div class="sw-popup-inner" style="<?php echo esc_attr( $attributes ); ?>">
				<a href="#" id="popup_close"><?php echo esc_html__( 'x', 'sw_popup' ); ?></a>
				<div class="sw-popup-content">
				<?php 
					if( get_option( 'popup_raw_html' ) != '' ){
						echo do_shortcode( get_option( 'popup_raw_html' ) );
					}else{
						if( $this->get_value( 'banner_img' ) ){ 
				?>
					<a href="<?php $this->get_value( 'pu_url' ) ?>"><?php echo wp_get_attachment_image( $this->get_value( 'banner_img' ), 'full' ); ?></a>
				<?php } 
					}
				?>
				</div>
			</div>
		</div>
		
		<script>
			(function($) {
				$('body').css( 'overflow', 'hidden' );
				var date = new Date();
				 var minutes = <?php echo ( $this->get_value( 'pu_expire' ) ) ? $this->get_value( 'pu_expire' ) : 15 ?>;
				 date.setTime(date.getTime() + (minutes * 60 * 1000));
				$.cookie('sw_popup', 0, { expires: date, path: '/' } );
				$(document).on( 'click', '#popup_close', function(e){
					$(this).parents( '.sw-popup-wrapper' ).remove();
					$.cookie('sw_popup', 1 );
					$('body').removeAttr( 'style' );
					e.preventDefault();
				});
			})(jQuery);
		</script>
<?php 
	}
}

new Sw_PopUp();
